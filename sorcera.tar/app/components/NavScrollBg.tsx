"use client";

import { useEffect } from "react";

export default function NavScrollBg() {
  useEffect(() => {
    const nav = document.querySelector(".nav");
    if (!nav) return;

    function onScroll() {
      if (window.scrollY > 8) {
        nav?.classList.add("nav-scrolled");
      } else {
        nav?.classList.remove("nav-scrolled");
      }
    }

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return null;
}
